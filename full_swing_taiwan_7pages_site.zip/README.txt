Full Swing Taiwan 多頁式網站

檔案說明：
- index.html：首頁
- simulator.html：Simulator
- kit-launch-monitor.html：KIT Launch Monitor
- solutions.html：Solutions
- gallery.html：Gallery
- case-studies.html：Case Studies
- contact.html：Contact
- style.css：共用樣式

使用方式：
1. 解壓縮 ZIP
2. 直接開啟 index.html
3. 或整個資料夾上傳至網站主機 / GitHub Pages / Netlify
